console.log("Script JS la ap mache!");
